# JARVIS CS2 BOOST — Extended Blueprint

## Session 2026-07-28 (13:xx – laufend)

```
╔══════════════════════════════════════════════════════════════╗
║              JARVIS CS2 AIM OPTIMIZATION BLUEPRINT           ║
║                    Ralph-Loop™ · BMAD™ · DEVKiTZ™            ║
╚══════════════════════════════════════════════════════════════╝
```

---

## 1. AGENDA

```
┌──────────────────────────────────────────────────────────┐
│ AGENDA                                                   │
├──────────────────────────────────────────────────────────┤
│ 1. SESSION CONTEXT LOAD (12:58 Recover)                  │
│    → Atuin-Log → Git-Versionierung → LibreChat-Summary   │
│    → Bulk .md → Chat-Metadaten-Archiv → Drive (locked)   │
│                                                          │
│ 2. CS2 NOTFALL AIM BOOST (Daemon)                        │
│    → pythonw notfall_aim_boost.py --daemon               │
│    → Pointer Speed = 6, Enhance Precision = OFF          │
│    → Auto-detect CS2, apply on launch                    │
│                                                          │
│ 3. GLOW BORDER (VISUAL FEEDBACK) — ENTFERNT              │
│    → glow-border.ps1 Fullscreen-Overlay                  │
│    → Problem: Fenster öffnet/schließt sich alle 3s       │
│    → Gelöscht: Kill + aus .exe entfernt                  │
│                                                          │
│ 4. CS2 OPTIMALE EINSTELLUNGEN                            │
│    → m_rawinput 1                                        │
│    → m_customaccel 0                                     │
│    → m_mouseaccel1 0 / m_mouseaccel2 0                   │
│    → viewmodel_presetpos 3                               │
│                                                          │
│ 5. EXE KOMPILIERUNG (C# → native Windows .exe)           │
│    → csc.exe (built-in .NET Framework Compiler)          │
│    → Kein Python/Node/Pip nötig                          │
│    → Kopiert nach Desktop                                │
└──────────────────────────────────────────────────────────┘
```

---

## 2. METHODIK: RALPH-LOOP™ (6 Phasen)

```
RALPH-LOOP™ — 6-Phasen Autonomer Agenten-Loop
─────────────────────────────────────────────────────────────

 P H A S E  1 :  L E S E N  (Read)
─────────────────────────────────────
   → Session 12:58 geladen (Atuin, Git, LibreChat)
   → JARVIS Projektstruktur erfasst
   → Vorhandene Skripte analysiert:
     • notfall_aim_boost.py (101 Zeilen)
     • glow-border.ps1 (119 Zeilen)
     • cs2_calibrator.py (325 Zeilen)
     • playwright_overlay.js (154 Zeilen)
     • full_dashboard.html (1166 Zeilen)
   → Status: CS2 läuft nicht, System bereit

 P H A S E  2 :  S P A W N  (Erzeugen)
─────────────────────────────────────
   → Starte notfall_aim_boost.py --daemon
   → Starte glow-border.ps1
   → Starte CS2 über steam://rungameid/730
   → Warte auf CS2-Prozess (PID 20080)

 P H A S E  3 :  E X E C U T E  (Ausführen)
─────────────────────────────────────
   → Daemon aktiv: Pointer Speed auf 6/20 gesetzt
   → Enhance Precision: AUS
   → CS2 Console-Befehle gesendet:
     • exec autoexec
     • viewmodel_presetpos 3
   → Überwachung alle 5s (Polling-Loop)
   → Traffic-Light: GRÜN (Boost aktiv)

 P H A S E  4 :  V E R I F Y  (Prüfen)
─────────────────────────────────────
   ✓ Pointer Speed = 6/20 (bestätigt)
   ✓ CS2 läuft (PID 20080)
   ⚠ Glow-Border: Fenster flackert alle 3s
   ⚠ User: "6/20 reicht nicht aus"
   ⚠ User: "Script geht über Spielbild"
   → Entscheidung: Glow-Border killen
   → Entscheidung: Pointer Speed anpassen

 P H A S E  5 :  C O M M I T  (Speichern)
─────────────────────────────────────
   → C# .exe kompiliert (JARVIS_CS2_BOOST.exe)
   → Auf Desktop kopiert
   → Glow-Border aus .exe entfernt
   → Aktuelle Settings eingefroren

 P H A S E  6 :  L O O P  (Wiederholen)
─────────────────────────────────────
   → User Feedback einholen
   → Settings nachjustieren
   → .exe neu bauen
   → Dokumentation schreiben ← JETZT
```

---

## 3. ARCHITEKTUR / KOMPONENTEN

```
┌─────────────────────────────────────────────────────────────────┐
│                    JARVIS CS2 BOOST ARCHITEKTUR                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  JARVIS_CS2_BOOST.exe  (6 KB, native C#, keine Dependencies)    │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  1. SetPointerSpeed(6)    ← SystemParametersInfoW(0x0071) │  │
│  │  2. SetEnhancePrecision(OFF) ← SystemParametersInfoW      │  │
│  │  3. Start notfall_aim_boost.py --daemon (pythonw, hidden)  │  │
│  │  4. Send CS2 Console Commands (PostMessageW)               │  │
│  │     → m_rawinput 1                                         │  │
│  │     → m_customaccel 0                                      │  │
│  │     → m_mouseaccel1 0 / m_mouseaccel2 0                    │  │
│  │     → viewmodel_presetpos 3                                │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  notfall_aim_boost.py  (101 Zeilen, Python Daemon)              │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  Loop alle 5s:                                            │  │
│  │  ┌─────────────────┐                                      │  │
│  │  │  Ist CS2 am Start?  │───Nein──→ Warte 5s               │  │
│  │  └────────┬────────┘                                      │  │
│  │           │ Ja                                             │  │
│  │           ↓                                                │  │
│  │  ┌─────────────────┐                                      │  │
│  │  │  Boost aktiv?      │───Ja──→ Warte 5s                   │  │
│  │  └────────┬────────┘                                      │  │
│  │           │ Nein                                           │  │
│  │           ↓                                                │  │
│  │  ┌─────────────────┐                                      │  │
│  │  │  Speed=6, Accel=OFF  │                                  │  │
│  │  │  exec autoexec        │                                  │  │
│  │  └─────────────────────┘                                  │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  glow-border.ps1  → ENTFERNT (verursachte Fenster-Flackern)    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. VERWENDETE TECHNOLOGIEN

```
┌──────────────────┬────────────────────────────────────────────┐
│ Technologie      │ Verwendung                                 │
├──────────────────┼────────────────────────────────────────────┤
│ C# (.NET 4.x)    │ Native .exe Kompilierung (csc.exe)         │
│ Python 3         │ notfall_aim_boost.py (Daemon-Loop)         │
│ PowerShell 5.1   │ Glow-Border (entfernt), Settings-Check     │
│ Win32 API        │ SystemParametersInfoW, FindWindowW,        │
│                  │ PostMessageW                               │
│ Steam Protocol   │ steam://rungameid/730 (CS2 Start)          │
│ Ralph-Loop™      │ 6-Phasen Agenten-Loop Methodik             │
│ BMAD™            │ Blueprint→Mapping→Analyse→Design           │
└──────────────────┴────────────────────────────────────────────┘
```

---

## 5. AKTUELLER ZUSTAND (Live)

```
┌────────────────────────────────────────────────────────────┐
│ STATUS:   🟢 CS2 läuft (PID 20080)                        │
│           🟢 Boost aktiv (Speed=6/20)                     │
│           🔴 Glow-Border: GELÖSCHT                        │
│           🟢 .exe auf Desktop                             │
│           ⚠ User: "6 reicht nicht" → Anpassung ausstehend │
└────────────────────────────────────────────────────────────┘
```

---

## 6. NÄCHSTE SCHRITTE (Backlog)

```
[ ] Pointer Speed erhöhen (User: "6 reicht nicht")
[ ] .exe neu kompilieren mit angepasstem Speed
[ ] Auto-Start einrichten (Scheduled Task / shell:startup)
[ ] Ralph-Loop für Daueroptimierung (längere Messstrecke)
[ ] Session archivieren (Drive, locked)
```

---

## 7. KOMMANDO-REFERENZ

```
────────────────────────────────────────────────────────────
STARTEN:
────────────────────────────────────────────────────────────
  Desktop .exe:     Doppelklick JARVIS_CS2_BOOST.exe
  Daemon only:      pythonw notfall_aim_boost.py --daemon
  CS2 starten:      steam://rungameid/730

────────────────────────────────────────────────────────────
PRÜFEN:
────────────────────────────────────────────────────────────
  Pointer Speed:    SystemParametersInfoW(0x0070)
  CS2 läuft?:       tasklist /FI "IMAGENAME eq cs2.exe"
  Boost aktiv?:     Prüfe Speed=6 + EnhancePrecision=OFF

────────────────────────────────────────────────────────────
KOMPILIEREN (.exe):
────────────────────────────────────────────────────────────
  csc.exe /target:winexe /out:JARVIS_CS2_BOOST.exe source.cs

────────────────────────────────────────────────────────────
NOTFALL:
────────────────────────────────────────────────────────────
  Kill alles:       Stop-Process -Name pythonw,powershell
  Reset Maus:       SystemParametersInfoW(0x0071, 0, 10, 0)
```

---

## 8. SESSION-CHRONIK

```
[13:xx] Session geladen (12:58: Atuin→Git→LibreChat→Archiv)
[13:xx] Projektstruktur analysiert (24 CS2-relevante Dateien)
[13:xx] notfall_aim_boost.py --daemon gestartet
[13:xx] glow-border.ps1 gestartet
[13:xx] CS2 via Steam gestartet
[13:xx] Boost aktiv bestätigt (Speed=6)
[13:xx] CS2 Console optimiert (rawinput, accel off)
[13:xx] Glow-Border gekillt (Fenster-Flackern)
[13:xx] C# .exe kompiliert (JARVIS_CS2_BOOST.exe)
[13:xx] .exe auf Desktop kopiert
[13:xx] Extended Blueprint erstellt (diese Datei)
```

---

*Generated by JARVIS Ultimate · Ralph-Loop™ Phase 6 · 2026-07-28*