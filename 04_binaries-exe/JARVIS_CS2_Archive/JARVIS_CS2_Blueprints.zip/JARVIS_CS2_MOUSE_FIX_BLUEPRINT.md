# JARVIS CS2 MOUSE FIX — Extended Sensitivity Blueprint

## Mouse Sensitivity Engine · XY-Achsen · Optimaler Mouse-Fix

```
╔══════════════════════════════════════════════════════════════════╗
║            JARVIS CS2 MOUSE SENSITIVITY ENGINE                  ║
║       Pointer Speed · Enhance Precision · Raw Input · XY        ║
║           Ralph-Loop™ · Win32 API · DEVKiTZ™                    ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## 1. DAS SKRIPT IM DETAIL: notfall_aim_boost.py

```
┌────────────────────────────────────────────────────────────────────┐
│  DATEI: notfall_aim_boost.py                                      │
│  PFAD: opencode/notfall_aim_boost.py                              │
│  LÄNGE: 101 Zeilen                                                │
│  SPRACHE: Python 3                                                 │
│  ZWECK: CS2 Notfall Aim Boost — Maus-Optimierung automatisch      │
│  STATUS: 🟢 Aktiv als Daemon (läuft im Hintergrund)               │
└────────────────────────────────────────────────────────────────────┘
```

### 1.1 KLASSENSTRUKTUR

```
notfall_aim_boost.py
│
├── WinMouse (Statische Klasse)
│   ├── set_pointer_speed(speed)       ← Setzt Windows Maus-Geschwindigkeit
│   ├── get_pointer_speed()            ← Liest aktuelle Geschwindigkeit
│   ├── set_enhance_precision(enable)  ← Schaltet Mausbeschleunigung AN/AUS
│   ├── is_cs2_running()              ← Prüft ob cs2.exe Prozess läuft
│   ├── get_cs2_hwnd()               ← Findet CS2 Fenster-Handle
│   └── send_console_cmd(cmd)         ← Sendet Befehl an CS2 Konsole
│
├── CS2AimBoost (Daemon-Klasse)
│   ├── __init__()                    ← Speichert originale Maus-Speed
│   ├── apply_boost()                 ← Wendet CS2-optimale Settings an
│   ├── remove_boost()                ← Stellt Original-Settings wieder her
│   ├── toggle()                      ← Umschalten zwischen Boost/Normal
│   ├── loop()                        ← Hauptloop: Prüft CS2 alle 5s
│   ├── start()                       ← Startet Daemon-Thread
│   └── stop()                        ← Stoppt Daemon + entfernt Boost
│
└── main (Entry Point)
    ├── --once                         ← Einmal ausführen und beenden
    ├── --daemon                       ← Als Dauerläufer starten
    └── (kein Argument)                ← Einmalig + Console-Befehle
```

### 1.2 WIN32 API: DIE MAGIE DAHINTER

```
╔══════════════════════════════════════════════════════════════════╗
║                    WIN32 API AUFRUFE                              ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  SystemParametersInfoW(0x0071, 0, speed, 0)                      ║
║  └── SPI_SETMOUSESPEED (0x0071)                                  ║
║      → Setzt Windows Maus-Zeigergeschwindigkeit                  ║
║      → Wertebereich: 1 (langsam) bis 20 (schnell)                ║
║      → Standard: 10 (Mitte)                                     ║
║      → CS2-Optimum: 6                                            ║
║                                                                  ║
║  SystemParametersInfoW(0x0070, 0, &speed, 0)                     ║
║  └── SPI_GETMOUSESPEED (0x0070)                                  ║
║      → Liest aktuelle Maus-Geschwindigkeit                        ║
║                                                                  ║
║  SystemParametersInfoW(0x0047, 0, {0,10,0|1}, 0)                 ║
║  └── SPI_SETMOUSE (0x0047)                                       ║
║      → Array[3]: {Threshold1, Threshold2, Acceleration}          ║
║      → Acceleration: 0 = AN (beschleunigt), 1 = AUS (linear)     ║
║      → CS2-Optimum: {0, 10, 1} = Enhance Precision AUS           ║
║                                                                  ║
║  FindWindowW(None, "Counter-Strike 2")                           ║
║  └── Findet CS2 Fenster anhand des Fenstertitels                  ║
║      → Rückgabe: Fenster-Handle (HWND) oder NULL                 ║
║                                                                  ║
║  PostMessageW(hwnd, 0x0100, ord(ch), 0)  ← WM_KEYDOWN            ║
║  PostMessageW(hwnd, 0x0101, ord(ch), 0)  ← WM_KEYUP              ║
║  └── Simuliert Tastendrücke im CS2-Fenster                        ║
║      → Wird genutzt um Console-Befehle zu senden                 ║
║      → Wie wenn der Spieler selbst tippt                         ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
```

### 1.3 DAEMON-LOGIK (Der Loop)

```
╔══════════════════════════════════════════════════════════════════╗
║               DAEMON LOOP — Alle 5 Sekunden                      ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  START ───────────────────────────────────────────────────────┐  ║
║    │                                                            │  ║
║    ├─→ tasklist /FI "IMAGENAME eq cs2.exe"                     │  ║
║    │     │                                                      │  ║
║    │     ├─→ cs2.exe GEFUNDEN?                                  │  ║
║    │     │     │                                                  │  ║
║    │     │     ├─→ JA: Ist Boost aktiv?                         │  ║
║    │     │     │     │                                            │  ║
║    │     │     │     ├─→ NEIN: apply_boost()                    │  ║
║    │     │     │     │     │   ├─ Speed=6                        │  ║
║    │     │     │     │     │   └─ EnhancePrecision=OFF           │  ║
║    │     │     │     │                                              │  ║
║    │     │     │     └─→ JA: Nichts tun (bereits aktiv)          │  ║
║    │     │     │                                                  │  ║
║    │     │     └─→ NEIN: Ist Boost aktiv?                        │  ║
║    │     │           │                                              │  ║
║    │     │           ├─→ JA: remove_boost()  ← CS2 geschlossen   │  ║
║    │     │           └─→ NEIN: Nichts tun                        │  ║
║    │     │                                                        │  ║
║    └─→ sleep(5) → zurück zum Anfang                              │  ║
║                                                                  ║
║  ENDE (bei PC-Neustart oder Stop)                                │  ║
║    ├─→ remove_boost()  ← Original-Einstellungen wiederherstellen │  ║
║    └─→ Thread beenden                                            │  ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## 2. XY-ACHSEN: SENSITIVITY IM DETAIL

```
╔══════════════════════════════════════════════════════════════════╗
║                 XY-ACHSEN — MOUSE SENSITIVITY                    ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  ┌─────────────────────────────────────────────────────────┐    ║
║  │                    BILDSCHIRM                            │    ║
║  │                                                          │    ║
║  │         (0,0) ──────────── X-Achse ────────────►       │    ║
║  │           │                                            │    ║
║  │           │                                            │    ║
║  │           │                                            │    ║
║  │         Y-Achse                                        │    ║
║  │           │              ● Ziel                        │    ║
║  │           │              Mauszeiger                     │    ║
║  │           │                                            │    ║
║  │           ▼                                            │    ║
║  │                                                          │    ║
║  └─────────────────────────────────────────────────────────┘    ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
```

### 2.1 WIE SENSITIVITY FUNKTIONIERT

```
MOUSE SENSITIVITY FORMEL:
──────────────────────────

  Maus-Bewegung (physisch)
       │
       ▼
  DPI (Hardware)           ← Sensor-Auflösung (z.B. 800 DPI)
       │
       ▼
  Windows Pointer Speed    ← 1-20 (6 = CS2-Optimum, kein Multiplier)
       │
       ▼
  Enhance Precision?       ← ON = Mausbeschleunigung (NICHT linear)
       │                    OFF = Linear (jede Bewegung = gleicher Faktor)
       ▼
  m_rawinput 0/1           ← 0 = Windows-Einstellungen werden angewendet
                             1 = Rohe Mausdaten direkt an CS2 (Empfohlen)
       │
       ▼
  CS2 in-game sensitivity  ← Multiplikator (z.B. 1.5)
       │
       ▼
  eDPI = DPI × ingame_sens ← Effektive DPI (z.B. 800 × 1.5 = 1200 eDPI)
```

### 2.2 X VS Y — WARUM GETRENNT?

```
X-ACHSE (horizontal / links-rechts):
─────────────────────────────────────
  m_yaw 0.022     ← Standard CS2 Yaw-Wert
  → Bestimmt wie schnell sich die Kamera horizontal dreht
  → Größerer Wert = schnellere horizontale Drehung
  → Standard 0.022 ist der Referenzwert (nicht ändern!)

Y-ACHSE (vertikal / hoch-runter):
─────────────────────────────────────
  m_pitch 0.022   ← Standard CS2 Pitch-Wert
  → Bestimmt wie schnell sich die Kamera vertikal bewegt
  → Gleicher Wert wie m_yaw = gleiche Geschwindigkeit in X und Y
  → Manche Pros: 0.020 (etwas langsamer vertikal = mehr Kontrolle)

UNTERSCHIED X VS Y:
────────────────────
  m_yaw > m_pitch  → Horizontale Bewegungen schneller als Vertikale
  m_yaw < m_pitch  → Vertikale Bewegungen schneller als Horizontale
  m_yaw = m_pitch  → Beide Achsen gleich schnell (Standard, empfohlen)

  WARUM?
  → Menschen bewegen die Maus natürlicherweise horizontal (Zielen auf
    Kopfhöhe) als vertikal (nach oben/unten zielen)
  → Viele Pros lassen beide Werte gleich für konsistentes Aim
  → Manche reduzieren m_pitch leicht für bessere Kontrolle beim Spray
```

### 2.3 DIE KOMPLETTE SENSITIVITY-KETTE

```
BEISPIEL: CS2 PRO SETUP (s1mple-artig)
─────────────────────────────────────────

  Hardware:
  └── DPI: 400
  └── Polling Rate: 1000 Hz (1ms)

  Windows:
  └── Pointer Speed: 6/20
  └── Enhance Precision: AUS

  CS2 Console:
  └── m_rawinput 1           ← Windows-Einstellungen werden IGNORIERT
  └── sensitivity 3.09       ← s1mple's Sens
  └── m_yaw 0.022
  └── m_pitch 0.022
  └── zoom_sensitivity_ratio_mouse 1.0

  eDPI: 400 × 3.09 = 1236

  WAS PASSIERT?
  ┌────────────────────────────────────────────────────────────────┐
  │ Maus 10cm bewegen → Sensor: 400 Punkte                        │
  │                    → CS2 liest rohe 400 Punkte (rawinput 1)    │
  │                    → Multipliziert mit sensitivity 3.09       │
  │                    → Multipliziert mit m_yaw 0.022            │
  │                    → = 400 × 3.09 × 0.022 = 27.19 Grad Drehung│
  └────────────────────────────────────────────────────────────────┘
```

---

## 3. DER OPTIMALE MOUSE-FIX

```
╔══════════════════════════════════════════════════════════════════╗
║           SCHRITT-FÜR-SCHRITT: OPTIMALEN MOUSE-FIX ERSTELLEN    ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  SCHRITT 1: AKTUELLE WERTE ERFASSEN                              ║
║  ───────────────────────────────────────────────                  ║
║  → Pointer Speed aktuell (get_pointer_speed)                     ║
║  → Enhance Precision Zustand                                     ║
║  → CS2 Registry: m_rawinput, m_yaw, m_pitch                     ║
║  → DPI des Spielers (muss erfragt werden)                        ║
║                                                                  ║
║  SCHRITT 2: CS2-OPTIMALE WERTE SETZEN                            ║
║  ───────────────────────────────────────────────                  ║
║  → Pointer Speed = 6 (Mitte, kein Multiplier)                    ║
║  → Enhance Precision = AUS (lineares Mausverhalten)             ║
║  → m_rawinput 1 (CS2 ignoriert Windows komplett)                ║
║  → m_customaccel 0 (keine CS2-interne Beschleunigung)           ║
║                                                                  ║
║  SCHRITT 3: DAEMON EINRICHTEN                                    ║
║  ───────────────────────────────────────────────                  ║
║  → Python-Skript mit Win32 API                                   ║
║  → Loop alle 5s: Prüfe ob CS2 läuft                             ║
║  → Boost AN wenn CS2 startet, AUS wenn CS2 schließt             ║
║  → Ursprungseinstellungen merken für Wiederherstellung           ║
║                                                                  ║
║  SCHRITT 4: IN .exe VERPACKEN (C# Kompilierung)                  ║
║  ───────────────────────────────────────────────                  ║
║  → C# Konsolen-App schreiben                                     ║
║  → Win32 P/Invoke: SystemParametersInfoW                         ║
║  → Start: pythonw notfall_aim_boost.py --daemon                 ║
║  → Kompilieren mit csc.exe (built-in .NET Compiler)             ║
║  → /target:winexe (kein Konsolen-Fenster)                       ║
║  → 6 KB fertige .exe                                             ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
```

### 3.1 DIE .exe IM DETAIL (JARVIS_CS2_BOOST.exe)

```
JARVIS_CS2_BOOST.exe (6 KB, C# .NET 4.x)
══════════════════════════════════════════

MAIN():
│
├─ 1. MOUSE EINSTELLEN
│    ├─ SystemParametersInfoW(0x0071, 0, 6, 0)
│    │   └── Pointer Speed = 6/20
│    │
│    └─ SystemParametersInfoW(0x0047, 0, {0,10,1}, 0)
│        └── Enhance Precision = AUS (Threshold1=0, Thr2=10, Accel=1)
│
├─ 2. DAEMON STARTEN
│    ├─ Process.Start("pythonw", "notfall_aim_boost.py --daemon")
│    ├─ WindowStyle = Hidden
│    └─ PID wird ausgegeben
│
├─ 3. CS2 FENSTER PRÜFEN
│    ├─ FindWindowW(null, "Counter-Strike 2")
│    ├─ Wenn gefunden:
│    │   ├─ m_rawinput 1
│    │   ├─ viewmodel_presetpos 3
│    │   ├─ m_customaccel 0
│    │   ├─ m_mouseaccel1 0
│    │   └─ m_mouseaccel2 0
│    │
│    └─ Wenn nicht gefunden:
│        └─ "Daemon boostet bei CS2-Start"
│
└─ 4. WARTEN AUF ENTER
     └─ Console.ReadLine() (bei /target:winexe unsichtbar)
```

### 3.2 DAS C# P/INVOKE (Die Windows Türöffner)

```
[IMPORT] — Wie C# mit Windows API redet
─────────────────────────────────────────

  [DllImport("user32.dll")]
  static extern bool SystemParametersInfoW(
      uint uiAction,    // Was tun? (0x0071, 0x0047, ...)
      uint uiParam,     // Parameter 1
      ref uint pvParam, // Parameter 2 (Wert oder Pointer)
      uint fWinIni      // Flags (0 = nicht speichern)
  );

  [DllImport("user32.dll")]
  static extern IntPtr FindWindowW(
      string lpClassName,  // Klassenname (null = egal)
      string lpWindowName  // Fenstertitel ("Counter-Strike 2")
  );

  [DllImport("user32.dll")]
  static extern bool PostMessageW(
      IntPtr hWnd,  // Ziel-Fenster
      uint Msg,     // Nachricht (0x0100=KEYDOWN, 0x0101=KEYUP)
      uint wParam,  // Tastencode (ord('m'), ord('_'), ...)
      uint lParam   // Zusatzinfos (0)
  );
```

### 3.3 KOMPILIEREN (So geht's)

```
KOMPILIERUNG (KEINE EXTRA TOOLS NÖTIG!)
─────────────────────────────────────────

  1. C# Source schreiben (JARVIS_CS2_BOOST.cs)
  2. Compiler finden:
     C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe

  3. Kompilieren:
     csc.exe /target:winexe /out:JARVIS_CS2_BOOST.exe JARVIS_CS2_BOOST.cs

  4. Flags:
     /target:winexe  → Windows Executable (kein Konsolen-Fenster)
     /target:exe      → Konsolen-App (Fenster sichtbar)
     /out:name.exe    → Ausgabedatei

  5. Ergebnis: 6 KB native .exe, läuft auf JEDEM Windows (ab 7)
     → Kein .NET Runtime nötig? DOCH! .NET Framework 4.x ist
       auf jedem modernen Windows vorinstalliert.
```

---

## 4. DIE MATHEMATIK HINTER DER SENSITIVITY

```
╔══════════════════════════════════════════════════════════════════╗
║              SENSITIVITY MATHEMATIK                              ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  FORMELN:                                                        ║
║  ────────                                                        ║
║                                                                  ║
║  eDPI = DPI × ingame_sensitivity                                 ║
║                                                                  ║
║  Drehung (Grad) = Mausbewegung(Counts) × sens × m_yaw           ║
║                                                                  ║
║  360° Drehung (cm) = (360 × 2.54) / (DPI × sens × m_yaw × 0.1)  ║
║                                                                  ║
║                                                                  ║
║  BEISPIELRECHNUNG:                                               ║
║  ─────────────────                                               ║
║  DPI: 800                                                        ║
║  Sens: 1.5                                                       ║
║  m_yaw: 0.022                                                    ║
║                                                                  ║
║  eDPI = 800 × 1.5 = 1200                                        ║
║                                                                  ║
║  360° Drehung = (360 × 2.54) / (800 × 1.5 × 0.022 × 0.1)       ║
║               = 914.4 / 2.64                                     ║
║               = 34.6 cm                                          ║
║                                                                  ║
║                                                                  ║
║  PRO VERGLEICH:                                                  ║
║  ──────────────────                                              ║
║  Spieler    | DPI | Sens | eDPI  | 360° (cm) | Bereich          ║
║  ───────────┼─────┼──────┼───────┼───────────┼───────────────── ║
║  s1mple     | 400 | 3.09 | 1236  | 33.6 cm   | Low Sens (Präzi) ║
║  ZywOo      | 800 | 1.46 | 1168  | 35.6 cm   | Low Sens (Präzi) ║
║  ropz       | 400 | 2.80 | 1120  | 37.1 cm   | Low Sens (Präzi) ║
║  NiKo       | 400 | 3.60 | 1440  | 28.8 cm   | Medium Sens      ║
║  donk       | 800 | 1.25 | 1000  | 41.6 cm   | Very Low Sens    ║
║  w0xic      | 400 | 5.00 | 2000  | 20.7 cm   | High Sens (Fast) ║
║  ───────────┴─────┴──────┴───────┴───────────┴───────────────── ║
║                                                                  ║
║  DURCHSCHNITT PRO: ~1000-1300 eDPI                              ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## 5. UNSERE AKTUELLEN EINSTELLUNGEN

```
AKTUELLER ZUSTAND (Live-Session 2026-07-28)
═════════════════════════════════════════════

  Windows:
  ├── Pointer Speed: 6/20                    🟢 (CS2-Optimum)
  ├── Enhance Precision: AUS                 🟢 (Lineares Verhalten)
  └── MouseThreshold1/2: 0/0                🟢 (Keine Beschleunigung)

  CS2 Console (per PostMessageW gesendet):
  ├── m_rawinput: 1                          🟢 (Raw Input = konsistent)
  ├── m_customaccel: 0                       🟢 (Keine CS2-Acceleration)
  ├── m_mouseaccel1: 0                       🟢
  ├── m_mouseaccel2: 0                       🟢
  └── viewmodel_presetpos: 3                 🟢 (Sichtbare Waffe)

  Daemon:
  ├── Status: Aktiv (läuft)                  🟢
  ├── Loop: Alle 5s                          🟢
  ├── Auto-Boost: Bei CS2-Start             🟢
  └── Auto-Remove: Bei CS2-Ende             🟢

  ⚠ USER-FEEDBACK:
    "6/20 reicht nicht aus" → Muss erhöht werden
```

### 5.1 WARUM 6/20 DAS CS2-OPTIMUM IST

```
WARUM 6/20?
════════════

  Windows Pointer Speed EFFEKT:
  ────────────────────────────────

  Speed 1-6:  Jeder Schritt = Multiplikator von 1.0
              → Keine Beschleunigung, kein Multiplier
              → Reine 1:1 Übertragung der Mausbewegung

  Speed 7-8:  Jeder Schritt = Multiplikator von 1.0
              → Immer noch linear, aber Windows Enhanced Precision
                schaltet sich bei Speed 7+ automatisch anders

  Speed 9-10: Leichter Multiplikator
              → MouseSpeed-Registry: 1 oder 2
              → MouseThreshold1/2 werden aktiv

  Speed 11+:  Deutlicher Multiplikator
              → MouseSpeed-Registry: 2
              → MouseThreshold1=6, MouseThreshold2=10 aktiv
              → Mausbeschleunigung (nicht linear!)

  FAZIT:
  ──────
  Speed 1-6 = Pure 1:1 Übertragung (KEINE Windows-Eingriffe)
  Speed 6   = Höchster Wert im 1:1-Bereich (optimal für CS2)
  Speed 7+  = Windows fügt Beschleunigung/Multiplikator hinzu

  ABER:
  Wenn der Spieler höhere Geschwindigkeit braucht:
  → DPI erhöhen (Hardware)
  → CS2 sensitivity erhöhen (In-Game)
  → NICHT Windows Speed über 6! (weil dann m_rawinput 1
    die Windows-Speed IGNORIERT und CS2 direkt liest)
```

---

## 6. FEHLERANALYSE: WAS HABEN WIR FALSCH GEMACHT?

```
PROBLEM: "6/20 reicht nicht aus"
═════════════════════════════════

  URSACHE:
  ────────
  Der Spieler ist höhere Pointer Speed gewohnt (z.B. 10/20).
  Mit m_rawinput 1 ignoriert CS2 zwar die Windows Speed,
  aber AUSSERHALB von CS2 (Desktop, Browser, andere Spiele)
  ist die Maus zu langsam.

  LÖSUNG:
  ───────
  Option A: Speed erhöhen (z.B. 10/20)
            → Aber dann im Desktop-Bereich anders als gewohnt
            → m_rawinput 1 macht es für CS2 egal

  Option B: DPI erhöhen + CS2-Sensitivity senken
            → Mehr Präzision bei gleicher Geschwindigkeit
            → Hardwareseitige Lösung

  Option C: m_rawinput 0 + Windows Speed anpassen
            → CS2 nutzt dann Windows-Einstellungen
            → Weniger konsistent (Windows kann eingreifen)

PROBLEM: "Fenster geht immer auf und zu"
══════════════════════════════════════════

  URSACHE:
  ────────
  glow-border.ps1 erstellt ein Fullscreen-Form mit
  Timer (400ms). Das Fenster ist TopMost, transparent,
  aber sichtbar. Es wird neu gezeichnet → flackert.

  LÖSUNG:
  ───────
  → Vollständig entfernt aus .exe
  → Kill: Stop-Process -Name powershell
```

---

## 7. OPTIMIERUNGSMATRIX

```
WELCHE EINSTELLUNG FÜR WELCHEN ZWECK?
═════════════════════════════════════════

  ┌──────────────────────┬──────────────────────┬────────────────────┐
  │ EINSTELLUNG          │ WERT                 │ EFFEKT             │
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ Pointer Speed        │ 1-20                 │ Windows Cursor-    │
  │                      │ CS2 Opt: 6           │ geschwindigkeit    │
  │                      │ User will: höher     │                    │
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ Enhance Precision    │ AN / AUS             │ Mausbeschleunigung │
  │                      │ CS2 Opt: AUS         │ (smooth aber       │
  │                      │                      │ ungenau)           │
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ m_rawinput           │ 0 = Windows          │ Rohe Mausdaten     │
  │                      │ 1 = Direkt           │ (empfohlen für     │
  │                      │ CS2 Opt: 1           │ Konsistenz)        │
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ m_yaw                │ 0.022 Standard       │ Horizontale        │
  │                      │                      │ Drehgeschwindigkeit│
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ m_pitch              │ 0.022 Standard       │ Vertikale          │
  │                      │ Pro: 0.018-0.020     │ Drehgeschwindigkeit│
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ m_customaccel        │ 0 = AUS              │ CS2-interne        │
  │                      │ 1-3 = Modi           │ Beschleunigung     │
  │                      │ CS2 Opt: 0           │                    │
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ DPI                  │ 400-3200             │ Hardware-Sensor-   │
  │                      │ CS2 Opt: 400-800     │ Auflösung          │
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ Polling Rate         │ 125-8000 Hz          │ USB-Abfragerate    │
  │                      │ CS2 Opt: 1000 Hz     │ (1000Hz = 1ms)     │
  ├──────────────────────┼──────────────────────┼────────────────────┤
  │ zoom_sensitivity_    │ 0.5-1.5              │ Sensitivität beim  │
  │ ratio_mouse          │ CS2 Opt: 1.0         │ Zielen (Zoom)      │
  └──────────────────────┴──────────────────────┴────────────────────┘
```

---

## 8. KOMMANDO-REFERENZ (Speziell Mouse/Sensitivity)

```
────────────────────────────────────────────────────────────────────────
MOUSE-EINSTELLUNGEN AUSLESEN (PowerShell):
────────────────────────────────────────────────────────────────────────
  Pointer Speed:       [System.Windows.Forms.SystemInformation]::MouseSpeed
  Registry Mouse:      Get-ItemProperty "HKCU:\Control Panel\Mouse"
  CS2 Registry:        Get-ItemProperty "HKCU:\Software\Valve\Source\cs2\Settings"

────────────────────────────────────────────────────────────────────────
MOUSE-EINSTELLUNGEN SETZEN (PowerShell):
────────────────────────────────────────────────────────────────────────
  Speed setzen:        SystemParametersInfoW(0x0071, 0, 6, 0)
  Enhance AUS:         SystemParametersInfoW(0x0047, 0, @(0,10,1), 0)
  Enhance AN:          SystemParametersInfoW(0x0047, 0, @(0,10,0), 0)

────────────────────────────────────────────────────────────────────────
CS2 CONSOLE BEFEHLE (Per PostMessageW):
────────────────────────────────────────────────────────────────────────
  m_rawinput 1         ← Raw Input AN
  sensitivity 2.5      ← In-Game Sens setzen
  m_yaw 0.022          ← Horizontale Geschwindigkeit
  m_pitch 0.022        ← Vertikale Geschwindigkeit
  m_customaccel 0      ← Keine Beschleunigung
  viewmodel_presetpos 3← Waffen-Position

────────────────────────────────────────────────────────────────────────
DIREKTE REGISTRY (Alternative):
────────────────────────────────────────────────────────────────────────
  Set-ItemProperty "HKCU:\Software\Valve\Source\cs2\Settings" \
    -Name m_rawinput -Value 1

────────────────────────────────────────────────────────────────────────
KOMPILIEREN (.exe):
────────────────────────────────────────────────────────────────────────
  csc.exe /target:winexe /out:JARVIS_CS2_BOOST.exe JARVIS_CS2_BOOST.cs

────────────────────────────────────────────────────────────────────────
DAEMON STEUERN:
────────────────────────────────────────────────────────────────────────
  Start:   pythonw notfall_aim_boost.py --daemon
  Stop:    taskkill /F /IM pythonw.exe
  Status:  Get-Process pythonw
```

---

## 9. RALPH-LOOP FÜR MOUSE-FIX (Angewendet)

```
RALPH-LOOP™ AUF DEN MOUSE-FIX ANGEWENDET
══════════════════════════════════════════

  P1 — LESEN:
  ├── notfall_aim_boost.py analysiert (101 Zeilen)
  ├── Win32 API Calls verstanden
  ├── CS2 Maus-Mechanik recherchiert (m_yaw, m_pitch)
  └── User-Feedback: "6/20 reicht nicht"

  P2 — SPAWN:
  ├── Daemon gestartet (pythonw --daemon)
  ├── CS2 gestartet (steam://rungameid/730)
  └── Boost applied (Speed=6, Accel=OFF)

  P3 — EXECUTE:
  ├── C# Source geschrieben (JARVIS_CS2_BOOST.cs)
  ├── Mit csc.exe kompiliert
  ├── Desktop .exe abgelegt
  └── Console-Befehle an CS2 gesendet

  P4 — VERIFY:
  ├── ✓ Speed=6 bestätigt
  ├── ✓ CS2 läuft (PID 20080)
  ├── ⚠ Glow-Border flackert → ENTFERNT
  └── ⚠ "6/20 reicht nicht" → Muss nachjustiert werden

  P5 — COMMIT:
  ├── .exe auf Desktop (JARVIS_CS2_BOOST.exe)
  ├── Blueprint dokumentiert (diese Datei)
  └── Session: 13:xx - laufend

  P6 — LOOP:
  └── NÄCHSTER DURCHGANG:
      → User sagt gewünschten Speed
      → .exe neu kompilieren mit angepasstem Wert
      → Erneut testen → Verify → Commit → Loop
```

---

## 10. BLUEPRINT: MOUSE-FIX VON NULL

```
BLUEPRINT: EIGENEN MOUSE-FIX ERSTELLEN
═════════════════════════════════════════

  WENN DU EINEN EIGENEN MOUSE-FIX BAUEN WILLST:

  1. SCRIPT (Python):
     ┌─────────────────────────────────────────────┐
     │ import ctypes                                │
     │ user32 = ctypes.windll.user32                │
     │                                              │
     │ # Speed setzen                               │
     │ user32.SystemParametersInfoW(0x0071, 0, 6, 0)│
     │                                              │
     │ # Enhance Precision AUS                      │
     │ user32.SystemParametersInfoW(0x0047, 0,      │
     │   (ctypes.c_int*3)(0,10,1), 0)               │
     └─────────────────────────────────────────────┘

  2. DAEMON (Loop-Logik):
     ┌─────────────────────────────────────────────┐
     │ while running:                               │
     │   if cs2_gestartet() and not boosted:        │
     │     apply_settings()                         │
     │   if not cs2_gestartet() and boosted:        │
     │     restore_settings()                       │
     │   time.sleep(5)                              │
     └─────────────────────────────────────────────┘

  3. C# .exe (Wrapper):
     → Siehe JARVIS_CS2_BOOST.cs
     → Kompilieren mit csc.exe

  4. AUTO-START (Optional):
     ┌─────────────────────────────────────────────┐
     │ # Task Scheduler                             │
     │ schtasks /create /tn "JARVIS_CS2_BOOST"     │
     │   /tr "JARVIS_CS2_BOOST.exe"                │
     │   /sc onlogon /ru "USER"                    │
     │                                              │
     │ # Oder: Startup-Ordner                       │
     │ shell:startup → .exe Verknüpfung reinlegen   │
     └─────────────────────────────────────────────┘

  5. REGISTRY CS2 (Optional):
     ┌─────────────────────────────────────────────┐
     │ Set-ItemProperty -Path                       │
     │   "HKCU:\Software\Valve\Source\cs2\Settings" │
     │   -Name m_rawinput -Value 1                  │
     └─────────────────────────────────────────────┘
```

---

## 11. GLOSSAR

```
eDPI      = Effective Dots Per Inch (DPI × ingame_sens)
            → Maß für die tatsächliche Mausgeschwindigkeit

DPI       = Dots Per Inch (Hardware-Sensor-Auflösung)
            → Wie viele Punkte pro Zoll Mausbewegung

Sensitivity = CS2-interner Multiplikator für die Drehgeschwindigkeit

m_yaw     = Horizontaler Drehfaktor (Standard: 0.022)

m_pitch   = Vertikaler Drehfaktor (Standard: 0.022)

m_rawinput = 0 = Windows-Verarbeitung, 1 = Direkter Maus-Input

Polling Rate = USB-Abfragerate (Hz), wie oft die Maus Daten sendet
               1000 Hz = alle 1ms

360° Distanz = Wie weit die Maus bewegt werden muss für eine
               volle 360-Grad-Drehung (in cm)

Pointer Speed = Windows Maus-Zeigergeschwindigkeit (1-20)
                CS2-Optimum: 6 (höchster 1:1 Wert)

Enhance Precision = Windows Mausbeschleunigung
                    AUS = lineares Verhalten
                    AN = Geschwindigkeit abhängig von Bewegungs-Tempo

Threshold1/2 = Schwellwerte für Windows-Mausbeschleunigung
               Ab 7+ Speed aktiv, unter 6 inaktiv
```

---

*Generated by JARVIS Ultimate · Ralph-Loop™ Phase 6 · Mouse-Fix Blueprint v1.0 · 2026-07-28*