#!/usr/bin/env python3
import ctypes, ctypes.wintypes, subprocess, time, sys, os, threading, signal, atexit

CTRL_C_EVENT = 0
kernel32 = ctypes.windll.kernel32

class WinMouse:
    @staticmethod
    def set_pointer_speed(speed):
        try: ctypes.windll.user32.SystemParametersInfoW(0x0071, 0, speed, 0); return True
        except: return False
    @staticmethod
    def get_pointer_speed():
        try: s=ctypes.wintypes.UINT(); ctypes.windll.user32.SystemParametersInfoW(0x0070,0,ctypes.byref(s),0); return s.value
        except: return 10
    @staticmethod
    def set_enhance_precision(enable):
        try: p=(ctypes.c_int*3)(0,10,0 if enable else 1); ctypes.windll.user32.SystemParametersInfoW(0x0047,0,p,0); return True
        except: return False
    @staticmethod
    def is_cs2_running():
        try:
            out = subprocess.run(['tasklist','/FI','IMAGENAME eq cs2.exe'],capture_output=True,text=True,timeout=5)
            return 'cs2.exe' in out.stdout
        except: return False
    @staticmethod
    def get_cs2_hwnd():
        try: return ctypes.windll.user32.FindWindowW(None, 'Counter-Strike 2')
        except: return None
    @staticmethod
    def send_console_cmd(cmd):
        hwnd = WinMouse.get_cs2_hwnd()
        if not hwnd: return False
        for ch in cmd + '\n':
            ctypes.windll.user32.PostMessageW(hwnd, 0x0100, ord(ch), 0)
            ctypes.windll.user32.PostMessageW(hwnd, 0x0101, ord(ch), 0)
        return True

class CS2AimBoost:
    def __init__(self):
        self.active = False
        self.orig_speed = WinMouse.get_pointer_speed()
        self.thread = None
        self.running = True
        signal.signal(signal.SIGINT, self.stop)
        signal.signal(signal.SIGTERM, self.stop)
        atexit.register(self.stop)
    def apply_boost(self):
        WinMouse.set_pointer_speed(6)
        WinMouse.set_enhance_precision(False)
        self.active = True
    def remove_boost(self):
        WinMouse.set_pointer_speed(self.orig_speed)
        self.active = False
    def toggle(self):
        if self.active: self.remove_boost()
        else: self.apply_boost()
    def loop(self):
        while self.running:
            ingame = WinMouse.is_cs2_running()
            if ingame and not self.active:
                self.apply_boost()
            elif not ingame and self.active:
                self.remove_boost()
            time.sleep(5)
    def start(self):
        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.thread.start()
    def stop(self):
        self.running = False
        self.remove_boost()

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='CS2 Notfall Aim Boost')
    parser.add_argument('--once', action='store_true', help='Einmal ausfuehren und beenden')
    parser.add_argument('--daemon', action='store_true', help='Als Daemon laufen (polling alle 5s)')
    args = parser.parse_args()
    boost = CS2AimBoost()
    if args.once:
        boost.apply_boost()
        print('Aim Boost aktiviert (Pointer Speed=6, Enhance Precision=AUS)')
        try:
            if WinMouse.is_cs2_running():
                WinMouse.send_console_cmd('exec autoexec')
                WinMouse.send_console_cmd('viewmodel_presetpos 3')
                print('CS2 Console-Befehle gesendet')
        except: pass
    elif args.daemon:
        boost.start()
        print('Aim Boost Daemon gestartet - ueberwacht CS2 alle 5s')
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            boost.stop()
    else:
        boost.apply_boost()
        print('Aim Boost aktiviert')
        if WinMouse.is_cs2_running():
            WinMouse.send_console_cmd('exec autoexec')
            WinMouse.send_console_cmd('viewmodel_presetpos 3')