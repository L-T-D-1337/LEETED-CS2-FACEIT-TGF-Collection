using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

class JARVIS_CS2_BOOST
{
    [DllImport("user32.dll")] static extern bool SystemParametersInfoW(uint a, uint b, ref uint c, uint d);
    [DllImport("user32.dll")] static extern bool SystemParametersInfoW(uint a, uint b, int[] c, uint d);
    [DllImport("user32.dll")