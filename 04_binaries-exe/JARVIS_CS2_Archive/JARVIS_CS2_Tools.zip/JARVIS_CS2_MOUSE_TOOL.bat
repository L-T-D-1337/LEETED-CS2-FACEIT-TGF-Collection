@echo off
title JARVIS CS2 Mouse Tool
color 0b
set LOGDIR=%USERPROFILE%\Desktop\JARVIS_LOGS
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set TS=%DATE:/=-%_%TIME::=-%
set TS=%TS: =0%
set TS=%TS:.=%

:: ===== BEFORE =====
echo. ===== JARVIS CS2 MOUSE TOOL v1.0 =====
echo.
echo [*] Erfasse aktuelle Einstellungen ...
call :capture "%LOGDIR%\mouse_before_%TS%.txt"
echo [OK] Vorher-Zustand gespeichert.
echo.

:: ===== APPLY =====
echo [*] Wende Mouse-Optimierung an ...
start /wait "" "%USERPROFILE%\Desktop\JARVIS_CS2_BOOST.exe"
echo [OK] Optimierung angewendet.
echo.

:: ===== AFTER =====
echo [*] Erfasse neue Einstellungen ...
call :capture "%LOGDIR%\mouse_after_%TS%.txt"
echo [OK] Nachher-Zustand gespeichert.
echo.

:: ===== DIFF =====
echo. ===== AENDERUNGEN =====
echo.
powershell -NoProfile -Command "& {
    $b = Get-Content '%LOGDIR%\mouse_before_%TS%.txt'
    $a = Get-Content '%LOGDIR%\mouse_after_%TS%.txt'
    for($i=0;$i -lt $b.Count;$i++){
        if($b[$i] -ne $a[$i]){Write-Host ('  [!] ' + $b[$i] + ' -> ' + $a[$i]) -ForegroundColor Yellow}
    }
}"
echo.
echo [i] Logs: %LOGDIR%
echo [i] Vorher: mouse_before_%TS%.txt
echo [i] Nachher: mouse_after_%TS%.txt
echo.
pause
exit /b

:capture
set OUTFILE=%1
echo === JARVIS CS2 MOUSE SETTINGS === > "%OUTFILE%"
echo Timestamp: %DATE% %TIME% >> "%OUTFILE%"
echo. >> "%OUTFILE%"
:: Pointer Speed
powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; Write-Host ('Pointer Speed: ' + [System.Windows.Forms.SystemInformation]::MouseSpeed + '/20')" >> "%OUTFILE%"
:: Enhance Precision
powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $sp = [System.Windows.Forms.SystemInformation]::MouseSpeed; $p=0; try{$k=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Control Panel\Mouse'); $v=$k.GetValue('MouseSpeed'); if($v -eq 0){Write-Host 'Enhance Precision: AUS'}elseif($v -eq 1){Write-Host 'Enhance Precision: AN (MouseSpeed='+$v+')'}else{Write-Host 'Enhance Precision: MouseSpeed='+$v}}catch{Write-Host 'Enhance Precision: UNBEKANNT'}" >> "%OUTFILE%"
:: CS2 Registry
powershell -NoProfile -Command "try{$k=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Valve\Source\cs2\Settings');if(!$k){Write-Host 'CS2 Registry: NICHT VORHANDEN'}else{foreach($n in $k.GetValueNames()){Write-Host ('CS2 '+$n+'='+$k.GetValue($n))}}}catch{Write-Host 'CS2 Registry: NICHT VORHANDEN'}" >> "%OUTFILE%"
:: Windows Mouse Registry
powershell -NoProfile -Command "try{$k=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Control Panel\Mouse');Write-Host ('MouseSensitivity: '+$k.GetValue('MouseSensitivity'));Write-Host ('MouseSpeed: '+$k.GetValue('MouseSpeed'));Write-Host ('MouseThreshold1: '+$k.GetValue('MouseThreshold1'));Write-Host ('MouseThreshold2: '+$k.GetValue('MouseThreshold2'))}catch{}" >> "%OUTFILE%"
echo. >> "%OUTFILE%"
echo === ENDE === >> "%OUTFILE%"
type "%OUTFILE%"
goto :eof