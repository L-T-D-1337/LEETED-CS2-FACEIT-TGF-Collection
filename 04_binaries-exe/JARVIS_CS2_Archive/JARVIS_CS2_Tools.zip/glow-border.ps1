Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type -TypeDefinition @'
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;

public class GlowForm : Form
{
    [DllImport("user32.dll")]
    static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
    [DllImport("user32.dll")]
    static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    const int WS_EX_LAYERED = 0x80000;
    const int WS_EX_TRANSPARENT = 0x20;
    const int GWL_EXSTYLE = -20;

    private Timer t;
    private bool pw, om;
    private int tick;
    private string statusText = "JARVIS · Idle";

    public GlowForm()
    {
        WindowState = FormWindowState.Maximized;
        FormBorderStyle = FormBorderStyle.None;
        TopMost = true;
        ShowInTaskbar = false;
        BackColor = Color.Black;
        TransparencyKey = Color.Black;
        Opacity = 0.85;
        DoubleBuffered = true;
        t = new Timer { Interval = 400 };
        t.Tick += (s, e) => { Tick(); Invalidate(); };
        t.Start();
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        int ex = GetWindowLong(Handle, GWL_EXSTYLE);
        SetWindowLong(Handle, GWL_EXSTYLE, ex | WS_EX_LAYERED | WS_EX_TRANSPARENT);
    }

    void Tick()
    {
        tick++;
        bool prevPw = pw, prevOm = om;
        pw = false; om = false;
        try {
            using (var wmi = new System.Management.ManagementObjectSearcher(
                "SELECT Name,CommandLine FROM Win32_Process"))
            using (var col = wmi.Get())
            {
                foreach (var o in col)
                {
                    string n = (o["Name"] + "").ToLower();
                    string c = (o["CommandLine"] + "").ToLower();
                    if (n.Contains("playwright")) pw = true;
                    if (n.Contains("openmanus")) om = true;
                    if (n == "node.exe" && (c.Contains("playwright") || c.Contains("npx") || c.Contains("test"))) pw = true;
                    if (n == "python.exe" && c.Contains("openmanus")) om = true;
                    if (n == "chromium.exe" || n == "chrome.exe") pw = true;
                }
            }
        } catch {}

        if (om) statusText = "⚡ OPENMANUS AKTIV · Rot";
        else if (pw) statusText = "◈ PLAYWRIGHT AKTIV · Rot blinkend";
        else statusText = "◈ JARVIS · Bereit";
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        var b = Screen.PrimaryScreen.Bounds;
        bool isActive = om || pw;

        // Always show subtle idle glow, intensify when active
        if (isActive)
        {
            Color c = Color.Red;
            bool blink = (pw && !om) ? (tick % 4 < 2) : true;
            if (blink)
            {
                int[] ws = { 28, 22, 16, 10, 4 };
                int[] alphas = { 15, 40, 70, 120, 200 };
                for (int i = 0; i < ws.Length; i++)
                {
                    int w = ws[i]; float off = w / 2f;
                    using (var p = new Pen(Color.FromArgb(alphas[i], c), w))
                        g.DrawRectangle(p, off, off, b.Width - w, b.Height - w);
                }
            }
        }
        else
        {
            // Subtle idle glow (cyan/blue)
            Color c = Color.Cyan;
            int alpha = 12 + (int)(Math.Sin(tick * 0.1) * 6);
            int w = 3; float off = w / 2f;
            using (var p = new Pen(Color.FromArgb(alpha, c), w))
                g.DrawRectangle(p, off, off, b.Width - w, b.Height - w);
        }

        // Small corner label
        using (var f = new Font("Segoe UI", 8, FontStyle.Regular))
        using (var b2 = new SolidBrush(Color.FromArgb(60, 255, 255, 255)))
        {
            g.DrawString(statusText, f, b2, b.Width - 200, b.Height - 22);
        }
    }
}
'@ -ReferencedAssemblies "System.Windows.Forms","System.Drawing","System.Management"

[GlowForm]::new().ShowDialog()
