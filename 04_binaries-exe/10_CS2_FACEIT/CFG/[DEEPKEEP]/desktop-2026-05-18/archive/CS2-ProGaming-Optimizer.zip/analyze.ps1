#Requires -RunAsAdministrator
# ============================================================
# CS2 Pro Gaming Optimizer — System-Analyse
# Scannt Hardware, BIOS, Treiber, CS2, FACEIT
# Output: JSON + Konsole
# ============================================================

param(
    [switch]$JsonOnly,
    [string]$OutputFile = ""
)

$ErrorActionPreference = "SilentlyContinue"
$results = @{}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  CS2 PRO GAMING — SYSTEM ANALYSE" -ForegroundColor White
Write-Host "========================================`n" -ForegroundColor Cyan

# --- 1. Windows Version ---
Write-Host "[1/12] Windows erkennen..." -ForegroundColor Yellow
$os = Get-CimInstance Win32_OperatingSystem
$build = [int](Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").CurrentBuildNumber
$winVer = if ($build -ge 22000) { "Windows 11" } else { "Windows 10" }
$results.OS = @{
    Version     = $winVer
    Build       = $os.BuildNumber
    Edition     = $os.Caption
    Architecture = $os.OSArchitecture
}
Write-Host "  $winVer (Build $($os.BuildNumber)) $($os.OSArchitecture)" -ForegroundColor Green

# --- 2. BIOS / UEFI ---
Write-Host "[2/12] BIOS / UEFI pruefen..." -ForegroundColor Yellow
$bios = Get-CimInstance Win32_BIOS
$fwType = if ($env:firmware_type -eq "UEFI" -or (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot")) { "UEFI" } else { "Legacy" }
$results.BIOS = @{
    Manufacturer = $bios.Manufacturer
    Version      = $bios.SMBIOSBIOSVersion
    FirmwareType = $fwType
}
Write-Host "  $($bios.Manufacturer) | $($bios.SMBIOSBIOSVersion) | $fwType" -ForegroundColor Green

# --- 3. TPM ---
Write-Host "[3/12] TPM pruefen..." -ForegroundColor Yellow
try {
    $tpm = Get-Tpm
    $tpmVer = (Get-CimInstance -Namespace "ROOT\CIMV2\Security\MicrosoftTpm" -ClassName Win32_Tpm).SpecVersion
    $results.TPM = @{
        Present = $tpm.TpmPresent
        Ready   = $tpm.TpmReady
        Version = if ($tpmVer) { $tpmVer.Split(",")[0].Trim() } else { "Unknown" }
    }
    $tpmColor = if ($tpm.TpmPresent -and $tpm.TpmReady) { "Green" } else { "Red" }
    Write-Host "  Present: $($tpm.TpmPresent) | Ready: $($tpm.TpmReady) | Version: $($results.TPM.Version)" -ForegroundColor $tpmColor
} catch {
    $results.TPM = @{ Present = $false; Ready = $false; Version = "N/A" }
    Write-Host "  TPM nicht verfuegbar!" -ForegroundColor Red
}

# --- 4. Secure Boot ---
Write-Host "[4/12] Secure Boot pruefen..." -ForegroundColor Yellow
try {
    $sb = Confirm-SecureBootUEFI
    $results.SecureBoot = @{ Enabled = $sb }
    $sbColor = if ($sb) { "Green" } else { "Red" }
    Write-Host "  Secure Boot: $sb" -ForegroundColor $sbColor
} catch {
    $results.SecureBoot = @{ Enabled = $false; Note = "Legacy BIOS oder nicht unterstuetzt" }
    Write-Host "  Secure Boot: Nicht bestimmbar (Legacy BIOS?)" -ForegroundColor Yellow
}

# --- 5. GPU ---
Write-Host "[5/12] GPU erkennen..." -ForegroundColor Yellow
$gpu = Get-CimInstance Win32_VideoController | Where-Object { $_.AdapterRAM -gt 0 } | Select-Object -First 1
$gpuBrand = if ($gpu.Name -match "NVIDIA") { "NVIDIA" } elseif ($gpu.Name -match "AMD|Radeon") { "AMD" } else { "Intel" }
$results.GPU = @{
    Name         = $gpu.Name
    Brand        = $gpuBrand
    DriverVersion = $gpu.DriverVersion
    VRAM_MB      = [math]::Round($gpu.AdapterRAM / 1MB, 0)
}
Write-Host "  $($gpu.Name) | $gpuBrand | VRAM: $($results.GPU.VRAM_MB) MB" -ForegroundColor Green

# --- 6. CPU ---
Write-Host "[6/12] CPU erkennen..." -ForegroundColor Yellow
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$results.CPU = @{
    Name            = $cpu.Name.Trim()
    Cores           = $cpu.NumberOfCores
    LogicalCores    = $cpu.NumberOfLogicalProcessors
    MaxClockMHz     = $cpu.MaxClockSpeed
}
Write-Host "  $($cpu.Name.Trim()) | $($cpu.NumberOfCores)C/$($cpu.NumberOfLogicalProcessors)T" -ForegroundColor Green

# --- 7. RAM ---
Write-Host "[7/12] RAM pruefen..." -ForegroundColor Yellow
$ram = Get-CimInstance Win32_PhysicalMemory | Measure-Object Capacity -Sum
$ramGB = [math]::Round($ram.Sum / 1GB, 1)
$results.RAM = @{ TotalGB = $ramGB; Sticks = $ram.Count }
Write-Host "  $ramGB GB ($($ram.Count) Sticks)" -ForegroundColor Green

# --- 8. Power Plan ---
Write-Host "[8/12] Power Plan pruefen..." -ForegroundColor Yellow
$activePlan = (powercfg /getactivescheme) -replace ".*GUID:\s*\S+\s*\(", "" -replace "\).*", ""
$isHighPerf = $activePlan -match "Hohe Leistung|High performance|Höchstleistung|Ultimate"
$results.PowerPlan = @{ Active = $activePlan.Trim(); IsHighPerformance = $isHighPerf }
$ppColor = if ($isHighPerf) { "Green" } else { "Yellow" }
Write-Host "  $($activePlan.Trim()) $(if (-not $isHighPerf) { '⚠ Nicht optimal!' })" -ForegroundColor $ppColor

# --- 9. Game DVR ---
Write-Host "[9/12] Game DVR Status..." -ForegroundColor Yellow
$gdvr = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" -Name AppCaptureEnabled -ErrorAction SilentlyContinue
$gdvrEnabled = if ($gdvr) { $gdvr.AppCaptureEnabled -eq 1 } else { $true }
$results.GameDVR = @{ Enabled = $gdvrEnabled }
$gdvrColor = if ($gdvrEnabled) { "Red" } else { "Green" }
Write-Host "  Game DVR: $(if ($gdvrEnabled) { 'AN ⚠ Deaktivieren!' } else { 'AUS ✓' })" -ForegroundColor $gdvrColor

# --- 10. Mouse Acceleration ---
Write-Host "[10/12] Maus-Beschleunigung..." -ForegroundColor Yellow
$mouseParams = Get-ItemProperty "HKCU:\Control Panel\Mouse"
$mouseAccel = $mouseParams.MouseSpeed -ne "0"
$results.MouseAcceleration = @{ Enabled = $mouseAccel; MouseSpeed = $mouseParams.MouseSpeed }
$maColor = if ($mouseAccel) { "Red" } else { "Green" }
Write-Host "  Maus-Beschleunigung: $(if ($mouseAccel) { 'AN ⚠' } else { 'AUS ✓' })" -ForegroundColor $maColor

# --- 11. CS2 ---
Write-Host "[11/12] CS2 suchen..." -ForegroundColor Yellow
$steamPath = (Get-ItemProperty "HKCU:\SOFTWARE\Valve\Steam" -ErrorAction SilentlyContinue).SteamPath
$cs2Found = $false
$cs2Path = ""
if ($steamPath) {
    $possiblePaths = @(
        "$steamPath\steamapps\common\Counter-Strike Global Offensive\game\bin\win64\cs2.exe",
        "$steamPath\steamapps\common\Counter-Strike 2\game\bin\win64\cs2.exe"
    )
    foreach ($p in $possiblePaths) {
        if (Test-Path $p) { $cs2Found = $true; $cs2Path = $p; break }
    }
    # Check additional library folders
    $libraryFolders = "$steamPath\steamapps\libraryfolders.vdf"
    if (Test-Path $libraryFolders) {
        $content = Get-Content $libraryFolders -Raw
        $paths = [regex]::Matches($content, '"path"\s+"([^"]+)"') | ForEach-Object { $_.Groups[1].Value }
        foreach ($lp in $paths) {
            $testPaths = @(
                "$lp\steamapps\common\Counter-Strike Global Offensive\game\bin\win64\cs2.exe",
                "$lp\steamapps\common\Counter-Strike 2\game\bin\win64\cs2.exe"
            )
            foreach ($tp in $testPaths) {
                if (Test-Path $tp) { $cs2Found = $true; $cs2Path = $tp; break }
            }
        }
    }
}
$results.CS2 = @{ Found = $cs2Found; Path = $cs2Path; SteamPath = $steamPath }
$cs2Color = if ($cs2Found) { "Green" } else { "Yellow" }
Write-Host "  CS2: $(if ($cs2Found) { "Gefunden: $cs2Path" } else { 'Nicht gefunden' })" -ForegroundColor $cs2Color

# --- 12. FACEIT ---
Write-Host "[12/12] FACEIT pruefen..." -ForegroundColor Yellow
$faceitPath = "$env:LOCALAPPDATA\FACEIT\FACEIT.exe"
$faceitInstalled = Test-Path $faceitPath
$faceitAC = Get-Service -Name "FACEIT" -ErrorAction SilentlyContinue
$results.FACEIT = @{
    Installed       = $faceitInstalled
    Path            = if ($faceitInstalled) { $faceitPath } else { "" }
    ACServiceRunning = if ($faceitAC) { $faceitAC.Status -eq "Running" } else { $false }
}
$fiColor = if ($faceitInstalled) { "Green" } else { "Yellow" }
Write-Host "  FACEIT: $(if ($faceitInstalled) { 'Installiert ✓' } else { 'Nicht gefunden' })" -ForegroundColor $fiColor

# --- FACEIT Readiness Score ---
$faceitScore = 0
if ($results.TPM.Present -and $results.TPM.Ready) { $faceitScore += 25 }
if ($results.SecureBoot.Enabled) { $faceitScore += 25 }
if (-not $results.GameDVR.Enabled) { $faceitScore += 15 }
if ($results.PowerPlan.IsHighPerformance) { $faceitScore += 10 }
if ($results.FACEIT.Installed) { $faceitScore += 15 }
if ($fwType -eq "UEFI") { $faceitScore += 10 }
$results.FACEITReadiness = @{ Score = $faceitScore; Max = 100 }

# --- Summary ---
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  FACEIT READINESS SCORE: $faceitScore / 100" -ForegroundColor $(if ($faceitScore -ge 80) { "Green" } elseif ($faceitScore -ge 50) { "Yellow" } else { "Red" })
Write-Host "========================================`n" -ForegroundColor Cyan

# --- JSON Output ---
$json = $results | ConvertTo-Json -Depth 4
if ($OutputFile) {
    $json | Out-File -FilePath $OutputFile -Encoding UTF8
    Write-Host "Ergebnis gespeichert: $OutputFile" -ForegroundColor Cyan
}
if ($JsonOnly) {
    Write-Output $json
} else {
    Write-Output $json
}
