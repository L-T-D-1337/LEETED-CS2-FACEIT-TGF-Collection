@echo off
title FACEIT Fix
echo ========================================
echo   FACEIT FIX + READINESS CHECK
echo ========================================
echo.

:: --- 1. FACEIT Cache loeschen ---
echo [1/6] FACEIT Cache loeschen...
if exist "%APPDATA%\FACEIT" (
    rd /s /q "%APPDATA%\FACEIT" 2>nul
    echo       FACEIT AppData Cache geloescht!
) else (
    echo       Kein FACEIT Cache gefunden
)
echo.

:: --- 2. FACEIT Local Cache ---
echo [2/6] FACEIT Local Cache loeschen...
if exist "%LOCALAPPDATA%\FACEIT" (
    for /d %%d in ("%LOCALAPPDATA%\FACEIT\*") do (
        if /i not "%%~nxd"=="FACEIT.exe" rd /s /q "%%d" 2>nul
    )
    del /q "%LOCALAPPDATA%\FACEIT\*.log" 2>nul
    echo       FACEIT Local Cache bereinigt!
) else (
    echo       Kein FACEIT Local Cache gefunden
)
echo.

:: --- 3. TPM Check ---
echo [3/6] TPM Status pruefen...
powershell -Command "$t=Get-Tpm; Write-Host ('  TPM Present: ' + $t.TpmPresent + ' | Ready: ' + $t.TpmReady)" 2>nul
echo.

:: --- 4. Secure Boot Check ---
echo [4/6] Secure Boot pruefen...
powershell -Command "try{$sb=Confirm-SecureBootUEFI; Write-Host ('  Secure Boot: ' + $sb)}catch{Write-Host '  Secure Boot: Nicht bestimmbar'}" 2>nul
echo.

:: --- 5. DNS Flush + Network Reset ---
echo [5/6] Netzwerk optimieren...
ipconfig /flushdns >nul 2>&1
netsh winsock reset >nul 2>&1
echo       DNS geflusht + Winsock Reset!
echo.

:: --- 6. Windows Update Status ---
echo [6/6] Windows Update Status...
powershell -Command "$build=[int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuildNumber; if($build -ge 22000){'  Windows 11 (Build '+$build+')'}else{'  Windows 10 (Build '+$build+')'}"
echo.

echo ========================================
echo   FACEIT FIX ABGESCHLOSSEN!
echo   Starte FACEIT Client neu.
echo   TPM 2.0 + Secure Boot = PFLICHT!
echo ========================================
echo.
pause
