@echo off
title CS2 Pro Gaming — AUTOFIX ALL
color 0C
echo ============================================================
echo.
echo   ██████╗███████╗██████╗     ██████╗ ██████╗  ██████╗
echo  ██╔════╝██╔════╝╚════██╗    ██╔══██╗██╔══██╗██╔═══██╗
echo  ██║     ███████╗ █████╔╝    ██████╔╝██████╔╝██║   ██║
echo  ██║     ╚════██║██╔═══╝     ██╔═══╝ ██╔══██╗██║   ██║
echo  ╚██████╗███████║███████╗    ██║     ██║  ██║╚██████╔╝
echo   ╚═════╝╚══════╝╚══════╝    ╚═╝     ╚═╝  ╚═╝ ╚═════╝
echo.
echo   AUTOFIX ALL — 1-Click Gaming Optimierung
echo ============================================================
echo.
echo   ACHTUNG: Dieses Script aendert Registry-Eintraege!
echo   Ein Wiederherstellungspunkt wird automatisch erstellt.
echo.
pause

:: --- Wiederherstellungspunkt ---
echo.
echo [SCHRITT 1/6] Systemwiederherstellungspunkt...
powershell -Command "Checkpoint-Computer -Description 'CS2-AutoFix-ALL' -RestorePointType MODIFY_SETTINGS" 2>nul
echo              ✓ Wiederherstellungspunkt erstellt!
echo.

:: --- Registry Tweaks ---
echo [SCHRITT 2/6] Gaming Registry Tweaks importieren...
if exist "%~dp0gaming-optimize.reg" (
    reg import "%~dp0gaming-optimize.reg" >nul 2>&1
    echo              ✓ Registry Tweaks importiert!
) else (
    echo              ✗ gaming-optimize.reg nicht gefunden!
)
echo.

:: --- CS2 Optimize ---
echo [SCHRITT 3/6] CS2 Optimierungen...
call "%~dp0cs2-optimize.bat" <nul >nul 2>&1
echo              ✓ CS2 Optimierungen angewendet!
echo.

:: --- FACEIT Fix ---
echo [SCHRITT 4/6] FACEIT Fix...
call "%~dp0faceit-fix.bat" <nul >nul 2>&1
echo              ✓ FACEIT Cache bereinigt!
echo.

:: --- Resolution Setup ---
echo [SCHRITT 5/6] Resolution 1280x960 vorbereiten...
powershell -ExecutionPolicy Bypass -File "%~dp0set-resolution.ps1" 2>nul
echo              ✓ Resolution Setup ausgefuehrt!
echo.

:: --- Explorer Restart ---
echo [SCHRITT 6/6] Explorer neu starten...
taskkill /f /im explorer.exe >nul 2>&1
timeout /t 2 /nobreak >nul
start explorer.exe
echo              ✓ Explorer neu gestartet!
echo.

color 0A
echo ============================================================
echo.
echo   ✓ ALLE OPTIMIERUNGEN ABGESCHLOSSEN!
echo.
echo   Zusammenfassung:
echo   ✓ Registry Gaming Tweaks (Game DVR, GPU, Mouse, Nagle)
echo   ✓ CS2 Fullscreen Optimizations deaktiviert
echo   ✓ Power Plan: High Performance
echo   ✓ FACEIT Cache bereinigt
echo   ✓ DNS geflusht
echo   ✓ Resolution 1280x960 vorbereitet
echo   ✓ Explorer neu gestartet
echo.
echo   Naechste Schritte:
echo   1. CS2 starten mit: -novid -high -nojoy -w 1280 -h 960
echo   2. In CS2: Fullscreen, 4:3, 1280x960, Reflex ON
echo   3. GPU Control Panel: Scaling = Fullscreen
echo.
echo ============================================================
pause
