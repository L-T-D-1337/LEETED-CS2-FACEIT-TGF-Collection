@echo off
echo ========================================
echo   Explorer wird neu gestartet...
echo ========================================
taskkill /f /im explorer.exe >nul 2>&1
timeout /t 2 /nobreak >nul
start explorer.exe
echo Explorer erfolgreich neu gestartet!
timeout /t 2 /nobreak >nul
