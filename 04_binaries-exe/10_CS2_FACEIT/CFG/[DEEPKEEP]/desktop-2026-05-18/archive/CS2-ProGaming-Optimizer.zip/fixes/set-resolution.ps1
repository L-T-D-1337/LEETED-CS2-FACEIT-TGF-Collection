#Requires -RunAsAdministrator
# ============================================================
# 1280x960 Stretched Resolution Setup
# Setzt GPU Scaling auf Fullscreen (NVIDIA/AMD)
# ============================================================

param(
    [int]$Width = 1280,
    [int]$Height = 960
)

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  RESOLUTION SETUP: ${Width}x${Height} STRETCHED" -ForegroundColor White
Write-Host "========================================`n" -ForegroundColor Cyan

# GPU erkennen
$gpu = Get-CimInstance Win32_VideoController | Where-Object { $_.AdapterRAM -gt 0 } | Select-Object -First 1

if ($gpu.Name -match "NVIDIA") {
    Write-Host "[NVIDIA] GPU Scaling konfigurieren..." -ForegroundColor Green
    Write-Host ""
    Write-Host "  NVIDIA Control Panel — Manuelle Schritte:" -ForegroundColor Yellow
    Write-Host "  1. Rechtsklick Desktop > NVIDIA Control Panel" -ForegroundColor White
    Write-Host "  2. Display > Adjust desktop size and position" -ForegroundColor White
    Write-Host "  3. Scaling mode: FULL-SCREEN" -ForegroundColor White
    Write-Host "  4. Perform scaling on: GPU" -ForegroundColor White
    Write-Host "  5. Override scaling mode: AKTIVIEREN" -ForegroundColor White
    Write-Host "  6. Apply" -ForegroundColor White
    Write-Host ""

    # NVIDIA Registry Scaling (Backup-Methode)
    $nvRegPath = "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Configuration"
    if (Test-Path $nvRegPath) {
        Get-ChildItem $nvRegPath -Recurse | ForEach-Object {
            $key = $_.PSPath
            if (Get-ItemProperty $key -Name "Scaling" -ErrorAction SilentlyContinue) {
                Set-ItemProperty $key -Name "Scaling" -Value 3  # 3 = Fullscreen
                Write-Host "  Registry Scaling gesetzt: $($_.Name)" -ForegroundColor DarkGray
            }
        }
        Write-Host "  NVIDIA Registry Scaling auf Fullscreen gesetzt!" -ForegroundColor Green
    }

} elseif ($gpu.Name -match "AMD|Radeon") {
    Write-Host "[AMD] GPU Scaling konfigurieren..." -ForegroundColor Red
    Write-Host ""
    Write-Host "  AMD Radeon Software — Manuelle Schritte:" -ForegroundColor Yellow
    Write-Host "  1. Rechtsklick Desktop > AMD Radeon Software" -ForegroundColor White
    Write-Host "  2. Gaming > Display" -ForegroundColor White
    Write-Host "  3. GPU Scaling: ENABLED" -ForegroundColor White
    Write-Host "  4. Scaling Mode: FULL PANEL" -ForegroundColor White
    Write-Host "  5. Ggf. Custom Resolution 1280x960 erstellen" -ForegroundColor White
    Write-Host ""

} else {
    Write-Host "[INTEL] Integrierte Grafik erkannt" -ForegroundColor Blue
    Write-Host "  Intel Graphics Command Center oeffnen" -ForegroundColor Yellow
    Write-Host "  Display > Scale: Stretch to full screen" -ForegroundColor White
}

# CS2 Launch Options fuer 1280x960
Write-Host "`n[CS2] Empfohlene Launch Options:" -ForegroundColor Cyan
Write-Host '  -w 1280 -h 960 -fullscreen -novid -high -nojoy' -ForegroundColor White

# CS2 Video Settings Erinnerung
Write-Host "`n[CS2] In-Game Settings:" -ForegroundColor Cyan
Write-Host "  Display Mode: Fullscreen" -ForegroundColor White
Write-Host "  Aspect Ratio: 4:3 (Normal)" -ForegroundColor White
Write-Host "  Resolution: 1280x960" -ForegroundColor White
Write-Host "  NVIDIA Reflex: Enabled + Boost" -ForegroundColor White
Write-Host "  V-Sync: DISABLED" -ForegroundColor White

Write-Host "`n✓ Setup abgeschlossen! Explorer wird neu gestartet..." -ForegroundColor Green

# Explorer Restart
taskkill /f /im explorer.exe 2>$null
Start-Sleep -Seconds 2
Start-Process explorer.exe

Write-Host "✓ Explorer neu gestartet!" -ForegroundColor Green
