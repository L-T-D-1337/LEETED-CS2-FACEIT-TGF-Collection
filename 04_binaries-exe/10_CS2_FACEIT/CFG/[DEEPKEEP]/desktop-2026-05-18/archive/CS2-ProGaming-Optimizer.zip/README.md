# CS2 Pro Gaming Optimizer

> All-in-One Tool für CS2/FACEIT Pro Gaming Optimierung
> Windows 10 & 11 · BAT + PowerShell + REG + HTA

---

## 🚀 Schnellstart

1. **Doppelklick auf `CS2-Optimizer.hta`**
2. Bei Nachfrage → **Als Administrator ausführen**
3. Tab "🔍 Analyse" → **System-Analyse starten**
4. Ergebnisse prüfen → Fixes anwenden

---

## 📋 Features

### 🔍 System-Analyse (12 Punkte)
- Windows 10/11 Auto-Erkennung
- BIOS/UEFI, TPM 2.0, Secure Boot
- GPU (NVIDIA/AMD/Intel), CPU, RAM
- Power Plan, Game DVR, Mouse Acceleration
- CS2 Installation, FACEIT Client

### 🎮 CS2 Optimizer
- Launch Options Builder
- 1280×960 Stretched Resolution Setup
- GPU Scaling (NVIDIA/AMD Auto-Detect)
- Pro Video Settings Referenz

### 🏆 FACEIT Fix
- Readiness Score (0-100)
- Cache Clear + Network Reset
- TPM/Secure Boot Status

### ⚡ Windows Tweaks (Toggle Switches)
- Game DVR, Power Plan, Mouse Accel
- Fullscreen Optimizations, GPU Priority
- Telemetrie

### 🤖 Copilot (Gemma 4)
- KI-Chat für individuelle Empfehlungen
- Liest System-Analyse-Daten
- Fallback: Rule-based wenn Ollama offline

### 💻 Terminal
- Direkter CMD/PowerShell Zugriff
- Eingebaute Shortcuts (help, analyse, autofix)

---

## ⚠️ Wichtig

- **Als Administrator ausführen** für Registry-Zugriff
- **Wiederherstellungspunkt** wird automatisch erstellt
- Registry-Änderungen können rückgängig gemacht werden
- FACEIT: TPM 2.0 + Secure Boot = **Pflicht**
- Video bleibt immer Englisch (NLM-Limitation)

---

## 📁 Dateien

```
CS2-ProGaming-Optimizer/
├── CS2-Optimizer.hta          ← Hauptprogramm
├── analyze.ps1                ← System-Scanner
├── fixes/
│   ├── gaming-optimize.reg    ← Registry Tweaks
│   ├── explorer-restart.bat   ← Explorer Restart
│   ├── set-resolution.ps1     ← 1280×960 Setup
│   ├── cs2-optimize.bat       ← CS2 Fixes
│   ├── faceit-fix.bat         ← FACEIT Fix
│   └── autofix-all.bat        ← Master Fix
└── README.md                  ← Diese Datei
```

---

*CS2 Pro Gaming Optimizer · 2026*
