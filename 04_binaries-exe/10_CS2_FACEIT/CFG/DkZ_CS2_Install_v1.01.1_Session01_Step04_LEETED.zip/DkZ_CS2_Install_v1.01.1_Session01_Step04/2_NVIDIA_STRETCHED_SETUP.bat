@echo off
:: ============================================================
::  DkZ devkitz - Nvidia 4:3 STRETCHED Setup (Windows)
::  Version: v1.01.1_Session01_Step04
::  Ziel: Bild wird IMMER auf Vollbild gestreckt (kein Balken)
:: ============================================================
title DkZ Nvidia Stretched Setup v1.01.1_Session01_Step04
color 0C
setlocal EnableDelayedExpansion

for /f %%a in ('"prompt $H&for %%b in (1) do rem"') do set "BS=%%a"
goto NV_START
:BANNER
cls
echo.
echo    ##      ######  ######  ########  ######  #####
echo    ##      ##      ##         ##     ##      ##  ##
echo    ##      #####   #####      ##     #####   ##   ##
echo    ##      ##      ##         ##     ##      ##  ##
echo    ######  ######  ######     ##     ######  #####
echo.
echo    ============ N V I D I A   S T R E T C H ============
echo                                       ... powered by DkZ
echo.
exit /b 0
:NV_START
call :BANNER


echo  Die GPU-Skalierung kann Windows/Nvidia aus Sicherheits-
echo  gruenden nicht per Script setzen - dieses Tool fuehrt
echo  dich in 60 Sekunden durch und oeffnet alles automatisch.
echo.
echo  --------------------------------------------
echo   SCHRITT 1 - NVIDIA SYSTEMSTEUERUNG
echo  --------------------------------------------
echo   Es oeffnet sich gleich die Nvidia Systemsteuerung.
echo   Dort links: "Anzeige" ^> "Desktop-Groesse und
echo   -Position anpassen" und dann:
echo.
echo     [1] Skalierungsmodus:      VOLLBILD  (nicht Seitenverh.!)
echo     [2] Skalierung ausfuehren: GPU
echo     [3] Haken setzen:          "Von Spielen und Programmen
echo                                 festgelegte Einstellung
echo                                 ausser Kraft setzen"
echo     [4] Uebernehmen
echo.
pause
start "" "%ProgramFiles%\NVIDIA Corporation\Control Panel Client\nvcplui.exe" 2>nul
if errorlevel 1 start "" nvcplui.exe 2>nul
echo.
echo  --------------------------------------------
echo   SCHRITT 2 - AUFLOESUNG IN CS2
echo  --------------------------------------------
echo   In CS2: Einstellungen ^> Video:
echo     Anzeigemodus:      Vollbild
echo     Seitenverhaeltnis: 4:3
echo     Aufloesung:        1280x960 (Empfehlung)
echo.
echo   Danach ist ALLES gestreckt: Desktop bleibt nativ,
echo   CS2 wird per GPU auf den ganzen Bildschirm gezogen.
echo.
echo  --------------------------------------------
echo   CHECK: Wenn noch schwarze Balken da sind ^>
echo   Nvidia-Panel: Skalierungsmodus steht noch auf
echo   "Seitenverhaeltnis" statt "Vollbild".
echo  --------------------------------------------
echo.
pause
