@echo off
:: ============================================================
::  DkZ devkitz - CS2 CSAFAP Installer
::  Version: v1.01.1_Session01_Step01
::  Installiert das CSAFAP Config Package UNVERAENDERT
::  exakt nach offizieller README (FNScence).
:: ============================================================
setlocal EnableDelayedExpansion
title DkZ CS2 Installer v1.01.1_Session01_Step01
color 0C

echo.
echo  ============================================
echo   DkZ devkitz ^| CS2 CSAFAP INSTALLER
echo   v1.01.1_Session01_Step01
echo  ============================================
echo.

:: ---- Steam-Pfad automatisch finden (Registry) ----
set "STEAM="
for /f "tokens=2*" %%a in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul') do set "STEAM=%%b"
if not defined STEAM set "STEAM=C:\Program Files (x86)\Steam"
set "STEAM=%STEAM:/=\%"

set "CS2=%STEAM%\steamapps\common\Counter-Strike Global Offensive"

:: ---- Falls CS2 auf anderer Library liegt: libraryfolders.vdf durchsuchen ----
if not exist "%CS2%\game\csgo\cfg" (
    for /f "usebackq tokens=2 delims=	 " %%p in (`findstr /i "path" "%STEAM%\steamapps\libraryfolders.vdf" 2^>nul`) do (
        set "LIB=%%~p"
        set "LIB=!LIB:\\=\!"
        if exist "!LIB!\steamapps\common\Counter-Strike Global Offensive\game\csgo\cfg" (
            set "CS2=!LIB!\steamapps\common\Counter-Strike Global Offensive"
        )
    )
)

if not exist "%CS2%\game\csgo\cfg" (
    color 0E
    echo  [FEHLER] CS2-Verzeichnis nicht gefunden!
    echo  Gesucht: %CS2%\game\csgo\cfg
    echo.
    set /p CS2="  Bitte CS2-Pfad manuell eingeben (bis '...Counter-Strike Global Offensive'): "
)
if not exist "%CS2%\game\csgo\cfg" (
    echo  [ABBRUCH] Pfad ungueltig. Nichts wurde veraendert.
    pause & exit /b 1
)

echo  [OK] CS2 gefunden: %CS2%
echo.

:: ---- Schritt 1 (README): csafap-Ordner nach game\csgo\cfg\ ----
echo  [1/3] Kopiere csafap nach game\csgo\cfg\ ...
xcopy /E /I /Y "%~dp0csafap" "%CS2%\game\csgo\cfg\csafap" >nul
if errorlevel 1 ( echo  [FEHLER] Kopieren fehlgeschlagen. & pause & exit /b 1 )

:: ---- Schritt 2 (README): csafap\csgo-Ordner nach game\ ----
echo  [2/3] Kopiere csafap\csgo nach game\ (platform_english.txt) ...
xcopy /E /I /Y "%~dp0csafap\csgo" "%CS2%\game\csgo" >nul
if errorlevel 1 ( echo  [FEHLER] Kopieren fehlgeschlagen. & pause & exit /b 1 )

:: ---- Schritt 3: DkZ Radar/Callout-Optimierung (separate Datei, CSAFAP bleibt unberuehrt) ----
echo  [3/3] Kopiere dkz_radar.cfg nach game\csgo\cfg\ ...
copy /Y "%~dp0dkz_radar.cfg" "%CS2%\game\csgo\cfg\dkz_radar.cfg" >nul

:: ---- Launch Options in Zwischenablage ----
set "LAUNCH=+exec csafap/main -testscript_inline "Test_Run ../../csgo/cfg/csafap/addons/.vtest""
echo %LAUNCH%| clip

echo.
echo  ============================================
echo   INSTALLATION ABGESCHLOSSEN [OK]
echo  ============================================
echo.
echo   NAECHSTE SCHRITTE (manuell, wichtig!):
echo.
echo   1. Oeffne "%CS2%\game\csgo\cfg\csafap\main.cfg"
echo      und trage OBEN deine Sensitivity ein!
echo.
echo   2. Steam ^> CS2 ^> Eigenschaften ^> Startoptionen einfuegen
echo      (liegt bereits in deiner ZWISCHENABLAGE - nur STRG+V):
echo      %LAUNCH%
echo.
echo   3. Im Spiel einmalig in die Konsole: exec dkz_radar
echo      (oder ans Ende deiner autoexec haengen)
echo.
echo   Radio-Wheels: H = CT Lineups ^| J = T Lineups
echo                 K = Crosshair/Modi ^| M = Maps + Practice
echo.
pause
