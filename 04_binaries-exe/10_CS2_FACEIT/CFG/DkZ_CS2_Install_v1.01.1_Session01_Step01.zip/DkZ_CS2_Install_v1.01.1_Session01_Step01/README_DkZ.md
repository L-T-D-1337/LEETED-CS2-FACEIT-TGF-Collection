# DkZ CS2 Install-Paket — v1.01.1_Session01_Step01

## Inhalt
| Datei | Zweck |
|---|---|
| `1_INSTALL_CSAFAP.bat` | Installiert CSAFAP unveraendert nach offizieller README, kopiert dkz_radar.cfg, legt Startoptionen in die Zwischenablage |
| `2_NVIDIA_STRETCHED_SETUP.bat` | Gefuehrtes Setup: GPU-Skalierung "Vollbild" (4:3 stretched, immer Fullscreen) |
| `dkz_radar.cfg` | Radar/Overview-Optimierung + eigener Standort-Callout (separate Datei) |
| `csafap/` | Original CSAFAP-Ordner (unveraendert) |
| `CSAFAP-original.zip` | Original-Repo-ZIP als Backup |
| `server-only/` | GoldKingZ Map-Configs (Server-Plugin, siehe HINWEIS.txt) |

## Reihenfolge
1. `1_INSTALL_CSAFAP.bat` als **Administrator** ausfuehren
2. `csafap\main.cfg` oeffnen → **Sensitivity oben eintragen**
3. Steam → CS2 → Startoptionen → **STRG+V** (liegt in Zwischenablage)
4. `2_NVIDIA_STRETCHED_SETUP.bat` ausfuehren
5. Im Spiel: `exec dkz_radar` in die Konsole

## Callouts auf der Karte — ehrliche Info
CS2 zeigt Callout-NAMEN nicht nativ als Text auf dem Radar/Overview
(das ging nur in CS:GO via SimpleRadar). `dkz_radar.cfg` holt das
Maximum raus: ganze Map sichtbar, groesseres Radar, eigener
Standort-Callout im HUD. Die CSAFAP Map-Guides zeigen zusaetzlich
1000+ Lineups direkt in-game (Taste M → Practice Mode).
