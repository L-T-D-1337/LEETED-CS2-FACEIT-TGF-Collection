[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\iaStor\Parameters\Port0]
"LPM"=dword:00000000
"LPMDSTATE"=dword:00000000
"DIPM"=dword:00000000

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\iaStor\Parameters\Port1]
"LPM"=dword:00000000
"LPMDSTATE"=dword:00000000
"DIPM"=dword:00000000

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\iaStor\Parameters\Port2]
"LPM"=dword:00000000
"LPMDSTATE"=dword:00000000
"DIPM"=dword:00000000

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\iaStor\Parameters\Port3]
"LPM"=dword:00000000
"LPMDSTATE"=dword:00000000
"DIPM"=dword:00000000

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\iaStor\Parameters\Port4]
"LPM"=dword:00000000
"LPMDSTATE"=dword:00000000
"DIPM"=dword:00000000

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\iaStor\Parameters\Port5]
"LPM"=dword:00000000
"LPMDSTATE"=dword:00000000
"DIPM"=dword:00000000